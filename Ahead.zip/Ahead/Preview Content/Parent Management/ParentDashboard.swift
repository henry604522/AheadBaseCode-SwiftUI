//
//  SwiftUIView.swift
//  Ahead
//
//  Created by Henry MacLane on 11/8/24.
//

import SwiftUI

struct ParentDashboard: View {
    var name: String = "Henry MacLane"
    var balance: Double = 1241.89
    var creditScore: Int = 741
    @State private var isExpanded = false
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea() // 1. Set page background to black
            
            VStack(alignment: .center) {
                HeaderView() // 2. Put the HeaderView at the top of the screen
                BalanceView() // 3. Put the account balance below it
                
                HStack {
                    Text("My Kids") // 5. Add text above it that says "My Kids"
                        .font(.title2)
                        .foregroundColor(.white)
                    Spacer()
                    ZStack {
                        Circle()
                            .fill(Color("MainColor"))
                            .frame(width: 30, height: 30)
                        Image(systemName: "plus")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                
            
                VStack(spacing: 16) {
                            HStack {
                                
                                Image(systemName: "person.circle.fill")
                                                    .font(.largeTitle)
                                                    .foregroundColor(.black)
                                                
                                
                                VStack(alignment: .leading) {
                                    Text("\(name)")
                                        .font(.title2)
                                        .fontWeight(.bold)
                                    Text("Card ending 5901")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                                Button(action: {
                                    // Add action for Pay button
                                }) {
                                    Text("Pay")
                                        .font(.headline)
                                        .padding(.horizontal, 16)
                                        .padding(.vertical, 8)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(Color.blue, lineWidth: 2)
                                        )
                                }
                            }
                            .padding()

                            HStack {
                                VStack {
                                    Image(systemName: "creditcard.fill")
                                        .font(.title)
                                        .foregroundColor(.purple)
                                    Text("$48.45")
                                        .font(.title)
                                        .fontWeight(.bold)
                                    Text("Card balance")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                                VStack {
                                    Image(systemName: "piggybank.fill")
                                        .font(.title)
                                        .foregroundColor(.purple)
                                    Text("\(creditScore)")
                                        .font(.title)
                                        .fontWeight(.bold)
                                    Text("Credit Score")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                            }
                            .padding(.horizontal)

                            Button(action: {
                                withAnimation {
                                    isExpanded.toggle()
                                }
                            }) {
                                HStack {
                                    Text("View More")
                                        .font(.headline)
                                    Spacer()
                                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                                }
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                            }

                            if isExpanded {
                                Text("Additional details go here...")
                                    .padding()
                            }
                        }
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(16)
                        .shadow(radius: 5)
                        .padding()
                    
                
                Spacer()
                
                Text("My finances") // 6. Below the rounded rectangle have text that says "My finances"
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding(.leading)
                
                Spacer()
                
            }
            .padding()
            
            
        }
    }
}

#Preview {
    ParentDashboard()
}

