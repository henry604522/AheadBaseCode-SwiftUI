//
//  AddSavingsGoalView.swift
//  Ahead
//
//  Created by Henry MacLane on 10/22/24.
//

import SwiftUI

struct AddSavingsGoalView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var name: String = ""
    @State private var targetAmount: String = ""
    @State private var targetDate: Date = Date()
    
    var onSave: (SavingsGoal) -> Void
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Goal Details")) {
                    TextField("Goal Name", text: $name)
                    TextField("Target Amount", text: $targetAmount)
                        .keyboardType(.decimalPad)
                    DatePicker("Target Date", selection: $targetDate, displayedComponents: .date)
                }
                
                Button(action: addGoal) {
                    Text("Add Goal")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .disabled(name.isEmpty || targetAmount.isEmpty)
            }
            .navigationTitle("Add New Goal")
        }
    }
    
    private func addGoal() {
        guard let amount = Double(targetAmount) else { return }
        let newGoal = SavingsGoal(name: name, targetAmount: amount, savedAmount: 0.0, targetDate: targetDate)
        onSave(newGoal)
        presentationMode.wrappedValue.dismiss()
    }
}
