//
//  Notifications.swift
//  Ahead
//
//  Created by Henry MacLane on 10/18/24.
//

import SwiftUI

struct Notifications: View {
    @State private var selectedSection: String = "Notifications"

    var body: some View {
        VStack(spacing: 30) {
            VStack(spacing: 20) {
                HStack(spacing: 80) { // Increased spacing between icons
                    // General Notifications
                    NotificationIcon(iconName: "bell.fill", title: "Notifications", selectedSection: $selectedSection)
                    
                    // Transactions
                    NotificationIcon(iconName: "dollarsign", title: "Transactions", selectedSection: $selectedSection)
                    
                    // Credit
                    NotificationIcon(iconName: "creditcard.fill", title: "Credit", selectedSection: $selectedSection)
                }
                .padding(.top)
                .frame(maxWidth: .infinity)

                Divider() // Adding a white divider
                    .background(Color.white)
                    .frame(height: 1) // Set divider height
                    .padding(.horizontal)
            }

            Spacer()
            
            if selectedSection == "Notifications" {
                NotificationContent(title: "Notifications", message: "No notifications to display")
            } else if selectedSection == "Transactions" {
                NotificationContent(title: "Transactions", message: "No transactions to display")
            } else if selectedSection == "Credit" {
                NotificationContent(title: "Credit", message: "No credit history")
            }
            
            Spacer()
        }
        .padding()
        .background(Color.black.ignoresSafeArea())
        .foregroundColor(.white)
    }
}

struct NotificationIcon: View {
    let iconName: String
    let title: String
    @Binding var selectedSection: String

    var body: some View {
        VStack {
            Button(action: {
                withAnimation {
                    selectedSection = title
                }
            }) {
                ZStack {
                    Circle()
                        .fill(Color("MainColor"))
                        .frame(width: 60, height: 60)
                    Image(systemName: iconName)
                        .foregroundColor(.white)
                        .font(.system(size: 24))
                }
            }
            Text(title)
                .font(.caption)
                .foregroundColor(.white)
        }
    }
}

struct NotificationContent: View {
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 10) {
            Text(title)
                .font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding(.horizontal)
    }
}

#Preview {
    Notifications()
}





