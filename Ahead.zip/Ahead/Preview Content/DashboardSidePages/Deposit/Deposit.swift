//
//  Deposit.swift
//  Ahead
//
//  Created by Henry MacLane on 10/10/24.
//

import SwiftUI
import MapKit
import Combine

struct Deposit: View {
    @State private var selectedTab: String = "Deposit"  // State to track the selected tab
    @State private var scrollViewProxy: ScrollViewProxy?  // Proxy to handle scroll actions
    @State private var isAtTop = true  // Track if user is at the top of the screen

    var body: some View {
        NavigationView {
            ScrollView {  // Ensure the entire view is scrollable
                ScrollViewReader { proxy in  // Enable scrolling and access to the scroll proxy
                    VStack(alignment: .leading) {
                        // Tabs Section
                        HStack {
                            // Deposit Tab
                            Button(action: {
                                withAnimation {
                                    selectedTab = "Deposit"
                                }
                            }) {
                                VStack {
                                    Text("Deposit")
                                        .font(.subheadline)
                                        .foregroundColor(.white)
                                    if selectedTab == "Deposit" {
                                        Color.main.frame(height: 2)
                                            .padding(.top, 2)
                                    } else {
                                        Color.clear.frame(height: 2)
                                    }
                                }
                            }
                            Spacer()
                            
                            // Withdraw Tab
                            Button(action: {
                                withAnimation {
                                    selectedTab = "Withdraw"
                                    proxy.scrollTo("WithdrawSection", anchor: .top)  // Scroll to Withdraw section and anchor to top
                                }
                            }) {
                                VStack {
                                    Text("Withdraw")
                                        .font(.subheadline)
                                        .foregroundColor(.white)
                                    if selectedTab == "Withdraw" {
                                        Color.blue.frame(height: 2)
                                            .padding(.top, 2)
                                    } else {
                                        Color.clear.frame(height: 2)
                                    }
                                }
                            }
                            Spacer()
                            
                            // Pay Tab
                            NavigationLink(destination: QR()) {
                                Button(action: {
                                    withAnimation {
                                        selectedTab = "Pay"  // Keep original behavior (no scrolling)
                                    }
                                }) {
                                    VStack {
                                        HStack(spacing: 4) {
                                            Text("Pay")
                                                .font(.subheadline)
                                                .foregroundColor(.white)
                                            Image(systemName: "qrcode")
                                                .foregroundColor(.white)
                                                .font(.caption)
                                        }
                                        if selectedTab == "Pay" {
                                            Color.blue.frame(height: 2)
                                                .padding(.top, 2)
                                        } else {
                                            Color.clear.frame(height: 2)
                                        }
                                    }
                                }
                            }
                            }
                            .padding(.horizontal)
                            .padding(.top, 100)  // Top padding for tabs section

                        Divider()  // Divider below the tabs
                            .padding(.top, 10)

                        // Deposit Section
                        VStack(spacing: 16) {
                            // ATM Button
                            NavigationLink(destination: AtmView()) {
                                HStack(spacing: 16) {
                                    Image(systemName: "banknote")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                        .background(Circle().fill(Color("MainColor")).frame(width: 40, height: 40))
                                    VStack(alignment: .leading) {
                                        Text("ATM")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                        Text("Find an ATM near you")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(Color.clear)
                            }

                            // Deposit from Card Button
                            NavigationLink(destination: CardDepositView()) {
                                HStack(spacing: 16) {
                                    Image(systemName: "creditcard")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                        .background(Circle().fill(Color("MainColor")).frame(width: 40, height: 40))
                                    VStack(alignment: .leading) {
                                        Text("Deposit from card")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                        Text("Deposit using another card")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(Color.clear)
                            }

                            // Bank Transfer Button (added back)
                            NavigationLink(destination: BankTransferView()) {
                                HStack(spacing: 16) {
                                    Image(systemName: "arrow.left.arrow.right")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                        .background(Circle().fill(Color("MainColor")).frame(width: 40, height: 40))
                                    VStack(alignment: .leading) {
                                        Text("Bank transfer")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                        Text("Link your bank")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(Color.clear)
                            }

                            // E-Check Button (added back)
                            NavigationLink(destination: ECheckView()) {
                                HStack(spacing: 16) {
                                    Image(systemName: "doc.text")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                        .background(Circle().fill(Color("MainColor")).frame(width: 40, height: 40))
                                    VStack(alignment: .leading) {
                                        Text("E-Check")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                        Text("Send e-check payments")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(Color.clear)
                            }
                        }
                        .padding(.horizontal)

                        // Divider below the Deposit section
                        Divider()
                            .padding(.top, 20)

                        // Withdraw Section (below the divider)
                        VStack(spacing: 16) {
                            Text("Withdraw")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .padding(.top, 20)

                            // ATM Button for Withdraw
                            NavigationLink(destination: AtmView()) {
                                HStack(spacing: 16) {
                                    Image(systemName: "banknote")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                        .background(Circle().fill(Color("MainColor")).frame(width: 40, height: 40))
                                    VStack(alignment: .leading) {
                                        Text("ATM")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                        Text("Find an ATM near you")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(Color.clear)
                            }

                            // Bank Transfer Button for Withdraw
                            NavigationLink(destination: BankTransferView()) {
                                HStack(spacing: 16) {
                                    Image(systemName: "arrow.left.arrow.right")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                        .background(Circle().fill(Color("MainColor")).frame(width: 40, height: 40))
                                    VStack(alignment: .leading) {
                                        Text("Bank transfer")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                        Text("Link your bank")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(Color.clear)
                            }
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 50)
                        .id("WithdrawSection")  // Add an ID for scrolling to this section

                        // Pay Section (with "Coming Soon" text)
                        if selectedTab == "Pay" {
                            VStack {
                                Text("Coming soon")
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .padding(.top, 20)
                                    .foregroundColor(.gray)
                            }
                        }

                        // BottomInfoView (Added to the bottom with more padding)
                        BottomInfoView()
                            .padding(.top, 70)  // Increased padding at the top
                    }
                    .background(Color.black)  // Make the internal background black
                    .onAppear {
                        self.scrollViewProxy = proxy  // Capture the proxy
                    }
                    .onReceive(Just(selectedTab)) { newValue in
                        if newValue == "Deposit" {
                            withAnimation {
                                proxy.scrollTo("Top", anchor: .top)  // Scroll back to the top
                            }
                        }
                    }
                }
            }
            .background(Color.black)  // Background for the entire scrollable view (ensures consistency at top and bottom)
            .ignoresSafeArea(.all)
            .navigationTitle("")
            .navigationBarHidden(true)  // Hide default navigation bar
        }
    }
}







struct AtmView: View {
    var body: some View {
        VStack {
            Text("Find an ATM near you")
                .font(.largeTitle)
                .padding()
            MapView()
                .clipShape(RoundedRectangle(cornerRadius: 25))
                .padding()
        }
        .background(Color(.systemGray6))
    }
}

struct MapView: UIViewRepresentable {
    func makeUIView(context: Context) -> MKMapView {
        return MKMapView(frame: .zero)
    }
    
    func updateUIView(_ view: MKMapView, context: Context) {
        // Configure map view here
    }
}

struct CardDepositView: View {
    @State private var cardNumber: String = ""
    @State private var cvv: String = ""
    @State private var expiryDate: String = ""
    @State private var cardholderName: String = ""
    @State private var zipCode: String = ""

    var body: some View {
        VStack(alignment: .leading) {
            Text("Deposit from card")
                .font(.largeTitle)
                .padding()
            
            Form {
                Section(header: Text("Card Information")) {
                    TextField("Card Number", text: $cardNumber)
                        .keyboardType(.numberPad)
                    TextField("CVV", text: $cvv)
                        .keyboardType(.numberPad)
                    TextField("Expiry Date", text: $expiryDate)
                        .keyboardType(.numbersAndPunctuation)
                    TextField("Cardholder Name", text: $cardholderName)
                    TextField("ZIP Code", text: $zipCode)
                        .keyboardType(.numberPad)
                }
            }
            .padding()

            Button(action: {
                // Perform card checks and legitimacy checks here
            }) {
                Text("Complete Payment")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
        }
        .background(Color(.systemGray6))
    }
}

struct ECheckView: View {
    @State private var images: [UIImage] = []

    var body: some View {
        VStack {
            Text("Scan check")
                .font(.largeTitle)
                .padding()
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.white)
                .frame(height: 300)
                .overlay(
                    VStack {
                        CameraViewDeposit(images: $images)
                        HStack {
                            ForEach(images, id: \.self) { image in
                                Image(uiImage: image)
                                    .resizable()
                                    .frame(width: 20, height: 30)
                            }
                        }
                        Button(action: {
                            // Handle continue action here
                        }) {
                            Text("Continue")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .padding()
                    }
                )
                .padding()
        }
        .background(Color(.systemGray6))
    }
}

struct CameraViewDeposit: UIViewControllerRepresentable {
    @Binding var images: [UIImage]

    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = UIViewController()
        // Configure camera UI here
        return viewController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}

struct BankTransferView: View {
    var body: some View {
        VStack {
            Text("Bank transfer")
                .font(.largeTitle)
                .padding()
            Button(action: {
                // Link bank action
            }) {
                Text("Link Bank")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
        }
        .background(Color(.systemGray6)) // Sets background to systemGray6
                .edgesIgnoringSafeArea(.all) // Optional, if you want the background to extend to safe areas
    }
}

#Preview {
    Deposit()
}


