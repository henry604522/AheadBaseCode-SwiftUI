//
//  Qr.swift
//  Ahead
//
//  Created by Henry MacLane on 10/29/24.
//

import SwiftUI
import AVFoundation
import CoreImage.CIFilterBuiltins

struct QR: View {
    @State private var selectedTab: Tab = .scan
       
       var body: some View {
           ZStack {
               // Render either the Camera View or the My Code View based on selection
               if selectedTab == .scan {
                   CameraView()
               } else {
                   MyCodeView()
               }
               
               // Bottom Tab Switcher
               VStack {
                   Spacer()
                   HStack {
                       TabButton(title: "Scan", isSelected: selectedTab == .scan) {
                           selectedTab = .scan
                       }
                       TabButton(title: "My Code", isSelected: selectedTab == .myCode) {
                           selectedTab = .myCode
                       }
                   }
                   .padding(.bottom, 30)
                   .background(Color.white.opacity(0.9))
               }
           }
           .edgesIgnoringSafeArea(.all) // Ensures full screen coverage
       }
    }

    enum Tab {
        case scan, myCode
    }

struct CameraView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIViewController {
        let cameraVC = UIViewController()
        let captureSession = AVCaptureSession()
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else { return cameraVC }
        let videoInput = try? AVCaptureDeviceInput(device: videoCaptureDevice)
        
        if let input = videoInput {
            captureSession.addInput(input)
        }
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.frame = UIScreen.main.bounds
        cameraVC.view.layer.addSublayer(previewLayer)
        
        captureSession.startRunning()
        return cameraVC
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
}

struct MyCodeView: View {
    @State private var qrCodeImage: Image? = nil
    
    var body: some View {
        VStack {
            if let qrCodeImage = qrCodeImage {
                qrCodeImage
                    .resizable()
                    .frame(width: 250, height: 250)
                    .padding()
            }
            
            Text("Users Name")
                .font(.headline)
                .padding(.top, 8)
            Text("Scan to pay Me")
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .onAppear {
            generateQRCode(from: "https://cash.app/$Henry604522")
        }
    }
    
    // Generate QR code from given string
    private func generateQRCode(from string: String) {
        let context = CIContext()
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(string.utf8)
        
        if let outputImage = filter.outputImage,
           let cgImage = context.createCGImage(outputImage, from: outputImage.extent) {
            let uiImage = UIImage(cgImage: cgImage)
            qrCodeImage = Image(uiImage: uiImage)
        }
    }
}

// Custom tab button view
struct TabButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .foregroundColor(isSelected ? .white : .gray)
                .padding()
                .frame(maxWidth: .infinity)
                .background(isSelected ? Color.blue : Color.clear)
                .clipShape(Capsule()) // Rounded like the buttons in your image
        }
    }
}

#Preview {
    QR()
}
