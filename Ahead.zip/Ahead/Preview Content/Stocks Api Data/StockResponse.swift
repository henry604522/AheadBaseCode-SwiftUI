//
//  StockResponse.swift
//  Ahead
//
//  Created by Henry MacLane on 10/4/24.
//

import Foundation

struct StockResponse: Decodable {
    let data: Stock
}
