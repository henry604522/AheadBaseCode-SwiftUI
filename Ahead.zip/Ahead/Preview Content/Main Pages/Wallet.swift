//
//  Wallet.swift
//  Ahead
//
//  Created by Henry MacLane on 10/1/24.
//
import SwiftUI

struct Wallet: View {
    @State private var userFullName: String = "Henry MacLane"
    @State private var lastFour: String = "9018"
    @State private var CVV: String = "123"
    @State private var EXP: String = "11/27"
    @State private var isCardLocked: Bool = false
    @State private var selectedCardIndex: Int = 0

    var body: some View {
        VStack(spacing: 0) {
        VStack(alignment: .leading, spacing: 0) { // Set spacing to 0 for the VStack
            // Text that changes based on the selected card
            VStack {
                Text(selectedCardIndex == 0 ? "Credit Card" : "Debit Card")
                    .font(.title)
                    .foregroundColor(Color.white)
                    .bold()
            }
                .padding(.horizontal)
            
            // Swipeable Credit Card Display
            TabView(selection: $selectedCardIndex) {
                ForEach(0..<2) { index in
                    VStack(alignment: .leading) {
                        // Credit Card Design
                        HStack {
                            Image("LOGO2")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                            Spacer()
                        }
                        .padding(.top)
                        
                        // Removed unnecessary Spacer
                        Text("XXXX XXXX XXXX \(lastFour)")
                            .font(.title2)
                            .foregroundColor(Color.white)
                            .lineLimit(1)
                            .bold()
                            .multilineTextAlignment(.center)
                            .padding(.top, 5) // Slight top padding to add space above text
                        
                        HStack {
                            VStack(alignment: .leading) {
                                Text(userFullName)
                                    .font(.headline)
                                    .foregroundColor(Color.white)
                                HStack {
                                    Text("CVV: \(CVV)")
                                        .font(.subheadline)
                                        .foregroundColor(Color.white)
                                    Spacer()
                                    Text("EXP: \(EXP)")
                                        .font(.subheadline)
                                        .foregroundColor(Color.white)
                                }
                            }
                        }
                        .padding(.bottom, 8) // Reduced bottom padding
                        
                        HStack {
                            Spacer()
                            Text("VISA")
                                .font(.title)
                                .foregroundColor(Color.white)
                                .bold()
                        }
                        .padding(.top, 5) // Kept existing top padding
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 10) // Control vertical space around the card
                    .frame(width: 350, height: 220)
                    .background(Color("MainColor"))
                    .cornerRadius(15)
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .padding(.top, -10) // Reduced padding above the card display
            
            // Custom Page Indicator
            HStack(spacing: 4) { // Reduced spacing between dots
                ForEach(0..<2) { index in
                    Circle()
                        .fill(selectedCardIndex == index ? Color("MainColor") : Color.white)
                        .frame(width: 8, height: 8)
                        .onTapGesture {
                            selectedCardIndex = index
                        }
                }
            }
            .frame(maxWidth: .infinity, alignment: .center)
            .padding(.top, 0) // hawk tuah
            .padding(.bottom, 80)
        }
            // Card Settings
            VStack(spacing: 0) {
                HStack {
                    Image(systemName: "lock")
                        .foregroundColor(Color.white)
                    Text(isCardLocked ? "Unlock Card" : "Lock Card")
                        .foregroundColor(Color.white)
                    Spacer()
                    Toggle("", isOn: $isCardLocked)
                        .labelsHidden()
                        .toggleStyle(SwitchToggleStyle(tint: Color("MainColor")))
                }
                .padding()
                
                VStack{
                    Divider()
                        .background(Color.black)
                }
                HStack {
                    Image(systemName: "applelogo")
                        .foregroundColor(Color.white)
                    Text("Add Card to Apple Pay")
                        .foregroundColor(Color.white)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.white)
                }
                .padding()

                VStack{
                    Divider()
                        .background(Color.black)
                }

                HStack {
                    Image(systemName: "arrow.2.squarepath")
                        .foregroundColor(Color.white)
                    Text("Replace Card")
                        .foregroundColor(Color.white)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.white)
                }
                .padding()
            }
            .background(Color("BLACK2"))
            .cornerRadius(15)
            .padding()
            .padding(.bottom, 100)

            Spacer()
        }
        .background(Color.black)
        .edgesIgnoringSafeArea(.all)
    }
}

struct Wallet_Previews: PreviewProvider {
    static var previews: some View {
        Wallet()
    }
}
