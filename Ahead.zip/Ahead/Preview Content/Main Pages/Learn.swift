//
//  Learn.swift
//  Ahead
//
//  Created by Henry MacLane on 10/1/24.
//

import SwiftUI

struct Learn: View {
    @State private var triviaScore: Int = 0
    @State private var questionIndex: Int = Int.random(in: 0..<Question.sampleQuestions.count)
    @State private var selectedAnswerIndex: Int? = nil
    @State private var isAnswered: Bool = false
    @State private var showTriviaQuestion: Bool = false // Controls trivia popup
    @State private var questions: [Question] = Question.sampleQuestions
    @State private var isEligibleForTrivia: Bool = checkEligibilityForTrivia() // Eligibility check

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                // Learn Section
                Text("Learn")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                
                Text("Continue Reading")
                    .font(.headline)
                    .foregroundColor(.white)
                
                // Continue Reading Icons
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(0..<4) { i in
                            VStack {
                                Image(systemName: "book.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .foregroundColor(.white)
                                Text("Article \(i + 1)")
                                    .foregroundColor(.white)
                            }
                            .frame(width: 100, height: 100)
                            .background(Color("BLACK2"))
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                }
                
                Divider()
                    .background(Color.white)
                
                // Trivia Section
                Text("Trivia")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                
                HStack {
                    Text("Daily Trivia")
                        .font(.headline)
                        .foregroundColor(Color.white)
                    
                    Spacer()
                    
                    HStack {
                        Image(systemName: "flame.fill")
                            .foregroundColor(triviaScore >= 1 ? .orange : .gray)
                        
                        Text("\(triviaScore)")
                            .font(.subheadline)
                            .foregroundColor(.white)
                        
                        Image(systemName: "chevron.right")
                            .foregroundColor(.white)
                    }
                    .padding(.trailing, 10)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color("BLACK2"))
                .cornerRadius(15)
                .padding(.horizontal)
                .onTapGesture {
                    if isEligibleForTrivia {
                        showTriviaQuestion = true
                    }
                }
                
                // Articles Section
                Text("Articles")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                
                ForEach(0..<6) { i in
                    HStack {
                        Image(systemName: "doc.text.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.white)
                        
                        Text("Article \(i + 1)")
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        Image(systemName: "chevron.right")
                            .foregroundColor(.white)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color("BLACK2"))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
            }
            .padding()
            .background(Color.black.edgesIgnoringSafeArea(.all))
        }
        .sheet(isPresented: $showTriviaQuestion) {
            TriviaQuestionView(
                question: questions[questionIndex],
                triviaScore: $triviaScore,
                onDismiss: {
                    showTriviaQuestion = false
                    markTriviaAttempted()
                    isEligibleForTrivia = false
                }
            )
        }
    }
}

// Trivia question popup view with 24-hour limit
struct TriviaQuestionView: View {
    let question: Question
    @Binding var triviaScore: Int
    @State private var selectedAnswerIndex: Int? = nil
    @State private var isAnswered: Bool = false
    var onDismiss: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text(question.question)
                .font(.headline)
                .foregroundColor(.white)
                .multilineTextAlignment(.leading)
            
            ForEach(0..<question.answers.count, id: \.self) { i in
                AnswerButton(text: question.answers[i],
                             isSelected: selectedAnswerIndex == i,
                             isCorrect: i == question.correctAnswerIndex,
                             isAnswered: isAnswered) {
                    if !isAnswered {
                        selectedAnswerIndex = i
                        isAnswered = true
                        triviaScore += 1 // Update score once a question is answered
                    }
                }
            }
            
            Button(action: onDismiss) {
                Text("Close")
                    .font(.body)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black)
                    .cornerRadius(10)
            }
        }
        .padding()
        .background(Color("BLACK2"))
        .cornerRadius(15)
        .padding(.horizontal)
        .background(Color.black.edgesIgnoringSafeArea(.all))
    }
}

// Answer button with color feedback
struct AnswerButton: View {
    let text: String
    let isSelected: Bool
    let isCorrect: Bool
    let isAnswered: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(text)
                .font(.body)
                .foregroundColor(isSelected ? .white : .white)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(answerBackgroundColor)
                .cornerRadius(10)
        }
        .disabled(isAnswered) // Disable button after selection
    }
    
    private var answerBackgroundColor: Color {
        if isAnswered {
            if isSelected {
                return isCorrect ? .green : .red
            } else if isCorrect {
                return .green.opacity(0.5)
            }
        }
        return Color("BLACK2")
    }
}

// Question model with correct answer index
struct Question {
    let question: String
    let answers: [String]
    let correctAnswerIndex: Int
    
    static let sampleQuestions: [Question] = [
        Question(question: "What is a budget?",
                 answers: ["A plan for saving and spending money", "A type of loan", "An investment strategy", "A credit score"],
                 correctAnswerIndex: 0),
        Question(question: "Why is it important to pay credit card bills on time?",
                 answers: ["To avoid late fees and interest", "It doesn't matter", "To qualify for rewards", "To get a loan"],
                 correctAnswerIndex: 0),
        // Add remaining questions with correct answer index...
    ]
}

// Eligibility check for trivia based on 24-hour cooldown
func checkEligibilityForTrivia() -> Bool {
    if let lastAttemptDate = UserDefaults.standard.object(forKey: "LastTriviaAttempt") as? Date {
        return Date().timeIntervalSince(lastAttemptDate) > 86400 // 24 hours in seconds
    }
    return true
}

// Mark trivia as attempted
func markTriviaAttempted() {
    UserDefaults.standard.set(Date(), forKey: "LastTriviaAttempt")
}

struct Learn_Previews: PreviewProvider {
    static var previews: some View {
        Learn()
    }
}





