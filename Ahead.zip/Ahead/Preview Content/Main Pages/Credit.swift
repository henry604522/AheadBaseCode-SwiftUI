//
//  Credit.swift
//  Ahead
//
//  Created by Henry MacLane on 10/22/24.
//

import SwiftUI

struct Credit: View {
    // Variables for credit score and points
    @State private var creditScore: Int = 732
    @State private var pointsSince: Int = 21
    
    // Function to return color based on credit score
    func colorForScore(_ score: Int) -> Color {
        switch score {
        case 0..<600: return Color.red
        case 600..<750: return Color.yellow
        case 750..<850: return Color.green
        default: return Color("MainColor")
        }
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Credit score gauge chart with score info
                ZStack {
                    VStack(spacing: 5) {
                        Text("Credit Score")
                            .font(.largeTitle)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                        
                        Text("TransUnion")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .offset(y: -180) // Adjust position to be above the circle gauge
                    
                    // Background circle for gauge
                    Circle()
                        .trim(from: 0.0, to: 0.75)
                        .stroke(Color("BLACK3"), lineWidth: 20)
                        .rotationEffect(Angle(degrees: 135))
                    
                    // Foreground circle for gauge
                    Circle()
                        .trim(from: 0.0, to: CGFloat(Double(creditScore) / 850.0 * 0.75))
                        .stroke(colorForScore(creditScore), lineWidth: 20)
                        .rotationEffect(Angle(degrees: 135))
                        .animation(.easeInOut, value: creditScore)
                    
                    // Draw filled small circles
                    let smallCircleRadius: CGFloat = 10
                    let smallCircleOffset: CGFloat = 78
                    
                    // Left small circle
                    Circle()
                        .fill(colorForScore(creditScore))
                        .frame(width: smallCircleRadius * 2, height: smallCircleRadius * 2)
                        .offset(x: -smallCircleOffset - smallCircleRadius, y: 88)
                    
                    // Right small circle
                    Circle()
                        .fill(Color("BLACK3"))
                        .frame(width: smallCircleRadius * 2, height: smallCircleRadius * 2)
                        .offset(x: 90, y: 88)
                    
                    // Display score info within the gauge
                    VStack(spacing: 8) {
                        Text("\(creditScore)") // Score in black
                            .font(.system(size: 55, weight: .bold))
                            .foregroundColor(.white)
                            .padding()
                        
                        HStack {
                            Image(systemName: "triangle.fill")
                                .resizable()
                                .scaledToFit()
                                .foregroundStyle(Color.green)
                                .frame(height: 10)
                                .offset(y: -3)
                            
                            Text("\(pointsSince) Past Month") // Points below gauge
                                .font(.headline)
                                .fontWeight(.regular)
                                .foregroundColor(.green)
                                .padding(.bottom, 10) // Space from bottom
                        }
                    }
                }
                .frame(width: 250, height: 250)
                .padding()
                .padding(.horizontal)
                .padding(.top, 80)
                .padding(.bottom, -10)
                .background(Color("BLACK2"))
                .cornerRadius(20)
                
                VStack {
                    Divider()
                        .background(Color.white)
                }
                    .padding(.vertical, 20)
                
                // Additional management features
                VStack(alignment: .leading, spacing: 15) {
                    Text("Manage Your Credit")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    
                    NavigationLink(destination: ContentView()) {
                        HStack {
                            Image(systemName: "calendar")
                                .font(.title)
                                .foregroundColor(.blue)
                            VStack(alignment: .leading) {
                                Text("Next Payment Due")
                                    .font(.headline)
                                    .foregroundStyle(Color.white)
                                Text("October 30, 2024")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                        }
                        .padding()
                        .background(Color("BLACK2"))
                        .cornerRadius(15)
                    }
                    
                    NavigationLink(destination: AccStatements()) {
                        HStack {
                            Image(systemName: "chart.bar.xaxis")
                                .font(.title)
                                .foregroundColor(.purple)
                            VStack(alignment: .leading) {
                                Text("Credit Statements")
                                    .font(.headline)
                                    .foregroundStyle(Color.white)
                                Text("Track your progress")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                        }
                        .padding()
                        .background(Color("BLACK2"))
                        .cornerRadius(15)
                    }
                    
                    NavigationLink(destination: Learn()) {
                        HStack {
                            Image(systemName: "lightbulb")
                                .font(.title)
                                .foregroundColor(.orange)
                            VStack(alignment: .leading) {
                                Text("Learn How to Boost Credit")
                                    .font(.headline)
                                    .foregroundStyle(Color.white)
                                Text("Get started with helpful tips")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                        }
                        .padding()
                        .background(Color("BLACK2"))
                        .cornerRadius(15)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
            .background(Color(.black))
        }
        .background(Color(.black).ignoresSafeArea()) // Extend background color to the whole view
    }
}

// Preview
struct Credit_Previews: PreviewProvider {
    static var previews: some View {
        Credit()
    }
}




