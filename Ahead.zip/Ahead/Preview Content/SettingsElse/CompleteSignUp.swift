//
//  SettingsSidePage.swift
//  Ahead
//
//  Created by Henry MacLane on 10/6/24.
//

import SwiftUI

struct CompleteSignUp: View {
    var body: some View {
        Text("On this page we will have the screen where they can view if there parent has signed up")
    }
}

#Preview {
    CompleteSignUp()
}
