//
//  Family.swift
//  Ahead
//
//  Created by Henry MacLane on 10/29/24.
//

import SwiftUI

struct Family: View {
    var body: some View {
        Text("Family")
    }
}

#Preview {
    Family()
}
