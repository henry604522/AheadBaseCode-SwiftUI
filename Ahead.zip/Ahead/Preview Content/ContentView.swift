//
//  ContentView.swift
//  Ahead
//
//  Created by Henry MacLane on 9/29/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        SignInView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

